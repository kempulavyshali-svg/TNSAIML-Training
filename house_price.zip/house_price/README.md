# House Price Prediction (Hyderabad)

Streamlit + scikit-learn project. Prices are shown in Indian Rupees (₹).

## Files
| File | Purpose |
|---|---|
| `house_price.py` | Main web app (Streamlit) |
| `house_price_cli.py` | Terminal version: trains models, prints metrics, saves a chart |
| `hyderabad_house_prices.csv` | Dataset (3,000 synthetic records, 12 localities) |
| `requirements.txt` | Python packages |

## Run in VS Code
1. Open the `house_price` folder in VS Code (File → Open Folder).
2. Open a terminal (Ctrl + `) and install packages once:
   ```
   pip install -r requirements.txt
   ```
3. Open `house_price.py` and press the **Run Python File** (▶) button.
   The browser opens automatically. (Or in terminal: `python house_price.py`)

For the terminal version: run `house_price_cli.py` the same way.

**Note:** the dataset is synthetic, for academic demonstration only; predictions are not for real financial decisions.
